function showAssignment4() {
   document.getElementById('assignment4').style.display = "block";
   document.getElementById('assignment5').style.display = "none";
      document.getElementById('gif').style.display = "none";

}

function showAssignment5() {
   document.getElementById('assignment5').style.display = "block";
   document.getElementById('assignment4').style.display = "none";
      document.getElementById('gif').style.display = "none";

}
function showAssignmentGif() {
   document.getElementById('gif').style.display = "block";
   document.getElementById('assignment4').style.display = "none";
   document.getElementById('assignment5').style.display = "none";

}
